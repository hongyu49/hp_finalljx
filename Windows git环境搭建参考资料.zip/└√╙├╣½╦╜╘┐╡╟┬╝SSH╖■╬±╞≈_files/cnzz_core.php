(function(){
try{
var d=window._CNZZDbridge_2895349.bobject;
d.callRequest([]);
d.callScript([]);
    d.createIcon(["<a href='http://www.cnzz.com/stat/website.php?web_id=2895349' target=_blank title='&#31449;&#38271;&#32479;&#35745;'>&#31449;&#38271;&#32479;&#35745;</a>"])}catch(err){
window._CNZZ_error_log=window._CNZZ_error_log||[];
window._CNZZ_error_log.push(err.fileName+"|"+err.lineNumber+"|"+err.message);
}
})();
